package com.example.projectwarrior

import android.app.Activity


class loginactivity : Activity()